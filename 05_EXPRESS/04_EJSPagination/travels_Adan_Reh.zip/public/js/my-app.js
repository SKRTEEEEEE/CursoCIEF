const cmon = document.getElementById("cmon")
cmon.innerHTML= "<h2>Estoy enviando esto desde Javascript</h2>";